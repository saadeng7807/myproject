<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\products;
use Illuminate\Support\Facades\DB;

class Shopping extends Controller
{
    public function List($categories_id)
    {
        $data=DB::table('products')
        ->where('categories_id','=',$categories_id)
        ->get();


        return view('shopping.list',['products'=>$data]);
    }


    public function Details($id)
    {
        $data=DB::table('products')
        ->where('id','=',$id)
        ->first();

      
        return view('shopping.details',['product'=>$data]);
    }
}
